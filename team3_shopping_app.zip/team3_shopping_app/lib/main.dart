import 'package:flutter/material.dart';
import 'package:team3_shopping_app/screens/auth_ui/forgot_pass/forgot_pass.dart';
import 'package:team3_shopping_app/screens/auth_ui/login/login.dart';
import 'package:team3_shopping_app/screens/auth_ui/sign_up/sign_up.dart';
import 'package:get/get.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const GetMaterialApp(title: 'Shopping App', home: LoginPage(),);
  }
}

